<?php
require_once 'config.php';
require_once 'includes/db_connection.php';

echo "<h1 style='color:green'>Connection Test Passed!</h1>";
echo "<p>Connected to: " . DB_NAME . " on " . DB_HOST . "</p>";
?>