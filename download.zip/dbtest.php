<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection FAILED: " . $conn->connect_error);
} else {
    echo "<h1 style='color:green'>Database Connected Successfully!</h1>";
    echo "<p>Host: " . DB_HOST . "<br>";
    echo "Database: " . DB_NAME . "</p>";
}

$conn->close();
?>