CREATE DATABASE IF NOT EXISTS placement_db;
USE placement_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student') DEFAULT 'student',
    full_name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    cgpa DECIMAL(3,2) DEFAULT 0.00,
    branch VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE job_drives (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    description TEXT,
    min_cgpa DECIMAL(3,2) NOT NULL,
    eligible_branch VARCHAR(50) NOT NULL,
    deadline DATE NOT NULL,
    posted_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    drive_id INT,
    status ENUM('Applied', 'Shortlisted', 'Selected', 'Rejected') DEFAULT 'Applied',
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (drive_id) REFERENCES job_drives(id)
);

-- Default Admin (password = "password")
INSERT INTO users (username, password, role, full_name, email) 
VALUES ('tpo', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Training & Placement Officer', 'tpo@college.com');