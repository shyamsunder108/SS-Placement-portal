<?php
require_once '../includes/header.php';
require_once '../includes/auth_check.php';   // ← protects the page
$result = $conn->query("SELECT a.*, j.title, j.company FROM applications a JOIN job_drives j ON a.drive_id = j.id WHERE a.student_id = " . $_SESSION['user_id']);
?>
<h2>My Applications</h2>
<table class="table">
    <thead><tr><th>Company</th><th>Job Title</th><th>Status</th><th>Applied On</th></tr></thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr><td><?php echo $row['company']; ?></td><td><?php echo $row['title']; ?></td><td><?php echo $row['status']; ?></td><td><?php echo $row['applied_date']; ?></td></tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php require_once '../includes/footer.php'; ?>