// Live search for jobs
function liveSearch() {
    let input = document.getElementById('searchInput');
    if (input) {
        input.addEventListener('keyup', function() {
            let filter = input.value.toUpperCase();
            let rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                let text = row.textContent.toUpperCase();
                row.style.display = text.indexOf(filter) > -1 ? '' : 'none';
            });
        });
    }
}
document.addEventListener('DOMContentLoaded', liveSearch);