<?php
// Must load config FIRST — this is the most important line
require_once __DIR__ . '/../config.php';

// Now use the constants from config.php
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: success message for testing (remove later)
// echo "<!-- Database connected successfully using " . DB_HOST . " -->";
?>