<?php
echo "<h1 style='color: green; text-align: center; margin-top: 100px;'>";
echo "Hosting is working! PHP is running.<br>";
echo "Now your real project should work after fixing config.php";
echo "</h1>";
phpinfo();
?>