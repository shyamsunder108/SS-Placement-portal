<?php 
require_once '../includes/header.php';
require_once '../includes/auth_check.php'; 
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (isset($_GET['updated'])) echo '<div class="alert alert-success">Profile Updated!</div>';
?>
<h2>My Profile</h2>
<form action="../actions/update_profile.php" method="POST">
    <div class="mb-3"><input type="text" value="<?php echo $student['full_name']; ?>" class="form-control" readonly></div>
    <div class="mb-3"><input type="email" value="<?php echo $student['email']; ?>" class="form-control" readonly></div>
    <div class="row">
        <div class="col-md-4"><input type="text" name="phone" value="<?php echo $student['phone']; ?>" class="form-control" placeholder="Phone"></div>
        <div class="col-md-4"><input type="number" step="0.01" name="cgpa" value="<?php echo $student['cgpa']; ?>" class="form-control" placeholder="CGPA"></div>
        <div class="col-md-4">
            <select name="branch" class="form-select">
                <option value="<?php echo $student['branch']; ?>" selected><?php echo $student['branch']; ?></option>
                <option value="CSE">CSE</option>
                <option value="ECE">ECE</option>
                <option value="ME">ME</option>
            </select>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mt-3">Update Profile</button>
</form>
<?php require_once '../includes/footer.php'; ?>