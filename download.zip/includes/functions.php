<?php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function getStudentCGPA($student_id) {
    global $conn;
    
    if (!$conn) {
        die("Database connection failed. Check db_connection.php");
    }
    
    $sql = "SELECT cgpa FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row ? $row['cgpa'] : 0;
}

function getStudentBranch($student_id) {
    global $conn;
    
    if (!$conn) {
        die("Database connection failed. Check db_connection.php");
    }
    
    $sql = "SELECT branch FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row ? $row['branch'] : '';
}
?>