<?php 
require_once '../includes/header.php';
require_once '../includes/auth_check.php';

if (!isAdmin()) {
    header("Location: ../index.php");
    exit;
}

if (isset($_GET['success'])) {
    echo '<div class="alert alert-success">Job drive posted successfully!</div>';
}
?>

<h2 class="mb-4">Post New Job Drive</h2>

<form action="../actions/post_drive_process.php" method="POST">
    <div class="mb-3">
        <label class="form-label">Job Title</label>
        <input type="text" name="title" class="form-control" required placeholder="e.g. Software Development Engineer">
    </div>
    
    <div class="mb-3">
        <label class="form-label">Company Name</label>
        <input type="text" name="company" class="form-control" required placeholder="e.g. Google, TCS, Infosys">
    </div>
    
    <div class="mb-3">
        <label class="form-label">Job Description</label>
        <textarea name="description" class="form-control" rows="5" required placeholder="Key responsibilities, skills required..."></textarea>
    </div>
    
    <div class="row">
        <div class="col-md-4 mb-3">
            <label class="form-label">Minimum CGPA</label>
            <input type="number" step="0.01" name="min_cgpa" class="form-control" required min="0" max="10" placeholder="e.g. 7.0">
        </div>
        
        <div class="col-md-4 mb-3">
            <label class="form-label">Eligible Branches</label>
            <select name="eligible_branch" class="form-select" required>
                <option value="">Select branch eligibility</option>
                <option value="All">All Branches</option>
                <option value="CSE">CSE / IT</option>
                <option value="ECE">ECE</option>
                <option value="ME">Mechanical</option>
                <option value="CE">Civil</option>
                <option value="EE">Electrical</option>
            </select>
        </div>
        
        <div class="col-md-4 mb-3">
            <label class="form-label">Application Deadline</label>
            <input type="date" name="deadline" class="form-control" required>
        </div>
    </div>
    
    <button type="submit" class="btn btn-primary btn-lg mt-3">
        <i class="bi bi-plus-circle"></i> Post Job Drive
    </button>
</form>

<?php require_once '../includes/footer.php'; ?>