<?php
// FIXED: Load everything before any code runs
require_once 'config.php';
require_once 'includes/functions.php';
session_start();

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    $redirect = isAdmin() ? "admin/dashboard.php" : "student/dashboard.php";
    header("Location: " . BASE_URL . $redirect);
    exit;
}

require_once 'includes/header.php'; 
?>
<div class="row justify-content-center mt-5">
    <div class="col-md-8 text-center">
        <h1 class="display-4 fw-bold">Welcome to Campus Placement Portal</h1>
        <p class="lead">Connecting Students with Dream Companies</p>
        <a href="login.php" class="btn btn-primary btn-lg me-3">Login</a>
        <a href="register.php" class="btn btn-success btn-lg">Register as Student</a>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>