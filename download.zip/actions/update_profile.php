<?php
require_once '../includes/db_connection.php';

$student_id = $_SESSION['user_id'];
$cgpa = $_POST['cgpa'];
$branch = $_POST['branch'];
$phone = $_POST['phone'];

$stmt = $conn->prepare("UPDATE users SET cgpa = ?, branch = ?, phone = ? WHERE id = ?");
$stmt->bind_param("dsdi", $cgpa, $branch, $phone, $student_id);
$stmt->execute();

header("Location: ../student/profile.php?updated=1");
?>