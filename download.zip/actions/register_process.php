<?php
session_start();
require_once '../includes/db_connection.php';

// Enable error reporting during development
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username   = trim($_POST['username'] ?? '');
    $password   = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);
    $full_name  = trim($_POST['full_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $cgpa       = floatval($_POST['cgpa'] ?? 0);
    $branch     = trim($_POST['branch'] ?? '');

    // Prepare statement – exact column order & names
    $sql = "INSERT INTO users (username, password, role, full_name, email, phone, cgpa, branch) 
            VALUES (?, ?, 'student', ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        // Show exact prepare error
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters – types: s = string, d = double
    $stmt->bind_param("sssssds", $username, $password, $full_name, $email, $phone, $cgpa, $branch);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Registration successful! Please login.";
        header("Location: ../login.php");
        exit;
    } else {
        echo "Execute failed: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}

$conn->close();
?>