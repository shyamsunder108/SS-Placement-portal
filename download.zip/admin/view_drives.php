<?php 
session_start();
require_once '../includes/header.php';
require_once '../includes/auth_check.php'; 
$result = $conn->query("SELECT * FROM job_drives ORDER BY created_at DESC");
?>
<h2>All Job Drives</h2>
<table class="table table-hover">
    <thead><tr><th>Title</th><th>Company</th><th>Min CGPA</th><th>Deadline</th></tr></thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr><td><?php echo $row['title']; ?></td><td><?php echo $row['company']; ?></td><td><?php echo $row['min_cgpa']; ?></td><td><?php echo $row['deadline']; ?></td></tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php require_once '../includes/footer.php'; ?>