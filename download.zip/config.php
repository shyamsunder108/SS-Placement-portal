<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// ∞ InfinityFree Database Credentials (MUST match your MySQL Databases page)
define('DB_HOST',     'sql211.infinityfree.com');     // ← from your dashboard (sql211 or sql3xx.epizy.com)
define('DB_USER',     'if0_41251040');                // ← your epiz username
define('DB_PASS',     'Eq7KNhjXin');                  // ← your real password (case-sensitive)
define('DB_NAME',     'if0_41251040_epiz_12345678_placement'); // ← exact database name

// Your live domain
define('BASE_URL',    'https://student-placement-portal.infinityfreeapp.com/');

// For debugging (keep for now, remove later)
echo "<!-- Debug: Trying to connect to " . DB_NAME . " on " . DB_HOST . " -->";
?>