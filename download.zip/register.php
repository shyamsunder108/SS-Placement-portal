<?php session_start(); ?>
<?php require_once 'includes/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-body">
                <h3 class="card-title text-center">Student Registration</h3>
                <form action="actions/register_process.php" method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3"><input type="text" name="username" class="form-control" placeholder="Username" required></div>
                        <div class="col-md-6 mb-3"><input type="password" name="password" class="form-control" placeholder="Password" required></div>
                    </div>
                    <div class="mb-3"><input type="text" name="full_name" class="form-control" placeholder="Full Name" required></div>
                    <div class="mb-3"><input type="email" name="email" class="form-control" placeholder="Email" required></div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><input type="text" name="phone" class="form-control" placeholder="Phone"></div>
                        <div class="col-md-4 mb-3"><input type="number" step="0.01" name="cgpa" class="form-control" placeholder="CGPA" required></div>
                        <div class="col-md-4 mb-3">
                            <select name="branch" class="form-select" required>
                                <option value="">Branch</option>
                                <option value="CSE">CSE</option>
                                <option value="ECE">ECE</option>
                                <option value="ME">ME</option>
                                <option value="CE">CE</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Register</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>