<?php
// ────────────────────────────────────────────────
//  FIXED auth_check.php – always loads config first
// ────────────────────────────────────────────────

require_once dirname(__DIR__) . '/config.php';     // ← MUST COME FIRST
require_once __DIR__ . '/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

if (!function_exists('isAdmin')) {
    function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}

// Optional: redirect non-admins away from admin pages
if (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false && !isAdmin()) {
    header("Location: " . BASE_URL . "student/dashboard.php");
    exit;
}
?>