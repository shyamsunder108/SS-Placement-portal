<?php
require_once '../includes/header.php';
require_once '../includes/auth_check.php';
require_once '../includes/functions.php';

$result = $conn->query("SELECT * FROM job_drives WHERE deadline >= CURDATE() ORDER BY created_at DESC");
$student_cgpa = getStudentCGPA($_SESSION['user_id']);
$student_branch = getStudentBranch($_SESSION['user_id']);
?>
<h2>Available Job Drives</h2>
<input type="text" id="searchInput" class="form-control mb-3" placeholder="Search jobs...">
<table class="table table-hover">
    <thead><tr><th>Company</th><th>Title</th><th>Min CGPA</th><th>Branch</th><th>Action</th></tr></thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): 
        $eligible = ($row['min_cgpa'] <= $student_cgpa) && ($row['eligible_branch'] == 'All' || $row['eligible_branch'] == $student_branch);
    ?>
        <tr>
            <td><?php echo $row['company']; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['min_cgpa']; ?></td>
            <td><?php echo $row['eligible_branch']; ?></td>
            <td>
                <?php if ($eligible): ?>
                    <form action="../actions/apply_process.php" method="POST" style="display:inline;">
                        <input type="hidden" name="drive_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" class="btn btn-success btn-sm">Apply Now</button>
                    </form>
                <?php else: ?>
                    <span class="text-danger">Not Eligible</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php require_once '../includes/footer.php'; ?>