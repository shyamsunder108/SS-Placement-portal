<?php 
session_start();
require_once '../includes/header.php';
require_once '../includes/functions.php';
require_once '../includes/auth_check.php';   // ← protects the page
$cgpa = getStudentCGPA($_SESSION['user_id']);
?>
<h2>Welcome, <?php echo $_SESSION['full_name']; ?>!</h2>
<div class="alert alert-info">Your CGPA: <strong><?php echo $cgpa; ?></strong></div>
<p>Check available jobs and apply now!</p>
<a href="view_jobs.php" class="btn btn-primary">Browse Jobs →</a>
<?php require_once '../includes/footer.php'; ?>