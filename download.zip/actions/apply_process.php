<?php
require_once '../includes/db_connection.php';

$student_id = $_SESSION['user_id'];
$drive_id = $_POST['drive_id'];

// Check if already applied
$check = $conn->prepare("SELECT id FROM applications WHERE student_id = ? AND drive_id = ?");
$check->bind_param("ii", $student_id, $drive_id);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    header("Location: ../student/view_jobs.php?already=1");
    exit;
}

$stmt = $conn->prepare("INSERT INTO applications (student_id, drive_id) VALUES (?, ?)");
$stmt->bind_param("ii", $student_id, $drive_id);
$stmt->execute();

header("Location: ../student/my_applications.php?success=1");
?>