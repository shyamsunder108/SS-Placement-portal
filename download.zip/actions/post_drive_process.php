<?php
require_once '../includes/db_connection.php';
require_once '../includes/auth_check.php';

if (!isAdmin()) {
    header("Location: ../index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title            = trim($_POST['title'] ?? '');
    $company          = trim($_POST['company'] ?? '');
    $description      = trim($_POST['description'] ?? '');
    $min_cgpa         = floatval($_POST['min_cgpa'] ?? 0);
    $eligible_branch  = trim($_POST['eligible_branch'] ?? '');
    $deadline         = $_POST['deadline'] ?? '';

    if (empty($title) || empty($company) || empty($description) || $min_cgpa <= 0 || empty($eligible_branch) || empty($deadline)) {
        header("Location: ../admin/post_drive.php?error=missing_fields");
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO job_drives 
        (title, company, description, min_cgpa, eligible_branch, deadline, posted_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param("sssdsdi", $title, $company, $description, $min_cgpa, $eligible_branch, $deadline, $_SESSION['user_id']);

    if ($stmt->execute()) {
        header("Location: ../admin/post_drive.php?success=1");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>