<?php
require_once '../includes/header.php';
require_once '../includes/auth_check.php';

// Only admin can access this page
if (!isAdmin()) {
    header("Location: " . BASE_URL . "student/dashboard.php");
    exit;
}

// Fetch all applications with student & job details
$query = "
    SELECT 
        a.id AS application_id,
        a.student_id,
        a.drive_id,
        a.status,
        a.applied_date,
        u.full_name AS student_name,
        u.email AS student_email,
        u.cgpa,
        u.branch AS student_branch,
        j.title AS job_title,
        j.company,
        j.min_cgpa AS required_cgpa,
        j.eligible_branch AS job_branch
    FROM applications a
    JOIN users u ON a.student_id = u.id
    JOIN job_drives j ON a.drive_id = j.id
    ORDER BY a.applied_date DESC
";

$result = $conn->query($query);
?>

<div class="container mt-4">
    <h2 class="mb-4">All Job Applications</h2>

    <?php if ($result->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Student Name</th>
                        <th>CGPA / Branch</th>
                        <th>Email</th>
                        <th>Company</th>
                        <th>Job Title</th>
                        <th>Required CGPA</th>
                        <th>Applied On</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $counter = 1;
                while ($row = $result->fetch_assoc()): 
                    $applied_date = date('d M Y, h:i A', strtotime($row['applied_date']));
                ?>
                    <tr>
                        <td><?= $counter++ ?></td>
                        <td><?= htmlspecialchars($row['student_name']) ?></td>
                        <td><?= number_format($row['cgpa'], 2) ?> / <?= htmlspecialchars($row['student_branch']) ?></td>
                        <td><?= htmlspecialchars($row['student_email']) ?></td>
                        <td><?= htmlspecialchars($row['company']) ?></td>
                        <td><?= htmlspecialchars($row['job_title']) ?></td>
                        <td><?= $row['required_cgpa'] ?></td>
                        <td><?= $applied_date ?></td>
                        <td>
                            <?php
                            $status = $row['status'];
                            $badge_class = match($status) {
                                'Applied'     => 'bg-primary',
                                'Shortlisted' => 'bg-info',
                                'Selected'    => 'bg-success',
                                'Rejected'    => 'bg-danger',
                                default       => 'bg-secondary'
                            };
                            ?>
                            <span class="badge <?= $badge_class ?> fs-6 px-3 py-2">
                                <?= $status ?>
                            </span>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="alert alert-info mt-4">
            <strong>Total Applications:</strong> <?= $result->num_rows ?>
        </div>

    <?php else: ?>
        <div class="alert alert-info text-center py-5">
            <h4>No applications received yet.</h4>
            <p>When students start applying, their details will appear here.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>