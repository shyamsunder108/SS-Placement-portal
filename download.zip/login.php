<?php 
session_start();
require_once 'includes/header.php'; 
if (isset($_GET['error'])) echo '<div class="alert alert-danger">Invalid credentials!</div>';
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow">
            <div class="card-body">
                <h3 class="card-title text-center">Login</h3>
                <form action="actions/login_process.php" method="POST">
                    <div class="mb-3"><input type="text" name="username" id="username" class="form-control" placeholder="Username" required></div>
                    <div class="mb-3"><input type="password" name="password" id="password" class="form-control" placeholder="Password" required></div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>