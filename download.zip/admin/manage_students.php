<?php session_start();
require_once '../includes/header.php';
require_once '../includes/auth_check.php';
$result = $conn->query("SELECT * FROM users WHERE role='student'");
?>
<h2>Manage Students</h2>
<table class="table">
    <thead><tr><th>Name</th><th>Email</th><th>CGPA</th><th>Branch</th></tr></thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr><td><?php echo $row['full_name']; ?></td><td><?php echo $row['email']; ?></td><td><?php echo $row['cgpa']; ?></td><td><?php echo $row['branch']; ?></td></tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php require_once '../includes/footer.php'; ?>