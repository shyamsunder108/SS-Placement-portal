<?php 
require_once __DIR__ . '/../includes/db_connection.php';
include '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/auth_check.php';

$total_drives = $conn->query("SELECT COUNT(*) FROM job_drives")->fetch_row()[0];
$total_students = $conn->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetch_row()[0];
$total_applications = $conn->query("SELECT COUNT(*) FROM applications")->fetch_row()[0];
?>
<h2>Admin Dashboard</h2>
<div class="row">
    <div class="col-md-4"><div class="card text-center"><div class="card-body"><h4><?php echo $total_drives; ?></h4><p>Job Drives</p></div></div></div>
    <div class="col-md-4"><div class="card text-center"><div class="card-body"><h4><?php echo $total_students; ?></h4><p>Students</p></div></div></div>
    <div class="col-md-4"><div class="card text-center"><div class="card-body"><h4><?php echo $total_applications; ?></h4><p>Applications</p></div></div></div>
</div>
<?php require_once '../includes/footer.php'; ?> 