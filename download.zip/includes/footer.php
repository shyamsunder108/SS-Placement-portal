</div>
<footer class="bg-dark text-white text-center py-3 mt-5">
    <p>&copy; <?php echo date("Y"); ?> Student Placement Portal BY-SSTHAKUR</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/script.js"></script>
</body>
</html>